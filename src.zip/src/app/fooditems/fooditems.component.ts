import { Component, OnInit } from '@angular/core';
import { Food } from '../models/food.model';
import { FoodService } from '../services/food/food.service';

@Component({
  selector: 'app-fooditems',
  templateUrl: './fooditems.component.html',
  styleUrls: ['./fooditems.component.css']
})
export class FooditemsComponent implements OnInit {

  foods:Food[]=[];
  constructor(private foodService:FoodService) { }

  ngOnInit(): void {
    this.foods=this.foodService.getAll();
  }

}
