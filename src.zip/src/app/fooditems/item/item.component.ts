import { Component, Injectable, Input, OnInit } from '@angular/core';
import { Food } from 'src/app/models/food.model';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
  @Input() foodItem:Food;  
  constructor() { }

  ngOnInit(): void {
  }

}
