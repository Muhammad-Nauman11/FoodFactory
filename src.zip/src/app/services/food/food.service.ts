import { Injectable } from '@angular/core';
import { Food } from 'src/app/models/food.model';

@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }
  getSpecific(){}
  getAll():Food[]{
    return [
    {
      id:0,
      name:'Burger',
      description:'A quick brown fox jumps over the lazy dog.',
      price:5,
      units:5,
      image:"assets/images/burger.jpg"
    },
    {
      id:0,
      name:'Pizza',
      description:'A quick brown fox jumps over the lazy dog.',
      price:5,
      units:5,
      image:"assets/images/pizza.jpg"
    },
    {
      id:0,
      name:'Karahi',
      description:'A quick brown fox jumps over the lazy dog.',
      price:5,
      units:5,
      image:"assets/images/karahi.jpg"
    },
    {
      id:0,
      name:'White Karahi',
      description:'A quick brown fox jumps over the lazy dog.',
      price:15,
      units:5,
      image:"assets/images/whiteKarahi.jpg"
    },
    {
      id:0,
      name:'Green Karahi',
      description:'A quick brown fox jumps over the lazy dog.',
      price:10,
      units:5,
      image:"assets/images/greenKarahi.jpg"
    },
    {
      id:0,
      name:'Sindhi Biryani',
      description:'A quick brown fox jumps over the lazy dog.',
      price:10,
      units:5,
      image:"assets/images/sindiBiryani.jpg"
    }, 
    {
      id:0,
      name:'Chinese Biryani',
      description:'A quick brown fox jumps over the lazy dog.',
      price:15,
      units:5,
      image:"assets/images/chineseBiryani.jpg"
    }, 
    {
      id:0,
      name:'Desi Food',
      description:'A quick brown fox jumps over the lazy dog.',
      price:25,
      units:5,
      image:"assets/images/indian.jpg"
    }
    ]
  }
}
//This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.