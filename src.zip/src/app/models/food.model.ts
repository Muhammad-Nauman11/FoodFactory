export interface Food {
    id:number
    name: string
    description: string
    price:number
    units:number
    image:string
  }