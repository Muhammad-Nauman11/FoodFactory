export interface User {
    id:number
    fullName: string
    username: string
    email:string
    password:string
    contact:string
  }